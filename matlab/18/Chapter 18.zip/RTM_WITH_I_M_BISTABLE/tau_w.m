function tau_w=tau_w(v);
tau_w=400./(3.3*exp((v+35)/20)+exp(-(v+35)/20));
