function w_inf=w_inf(v);
w_inf=1./(1+exp(-(v+35)/10));