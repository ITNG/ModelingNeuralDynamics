function r_inf=r_inf(v);

r_inf=1./(1+exp((v+84)/10.2));
