function tau_r=tau_r(v);

tau_r=1./(exp(-14.59-0.086*v)+exp(-1.87+0.0701*v));

