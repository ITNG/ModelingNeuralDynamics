function alpha_n=alpha_n(v) 

alpha_n=(95-v)./(exp((95-v)/11.8)-1);