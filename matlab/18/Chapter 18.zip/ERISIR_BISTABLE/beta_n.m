function beta_n=beta_n(v)
beta_n=0.025./exp(v/22.222);