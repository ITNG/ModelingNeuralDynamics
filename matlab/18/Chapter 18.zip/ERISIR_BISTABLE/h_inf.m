function h_inf=h_inf(v);
h_inf=alpha_h(v)./(alpha_h(v)+beta_h(v));