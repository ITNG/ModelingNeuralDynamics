function beta_m=beta_m(v) 
beta_m=1.2262./exp(v/42.248);