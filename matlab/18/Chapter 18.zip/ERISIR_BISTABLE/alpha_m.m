function alpha_m=alpha_m(v) 
alpha_m=40*(75.5-v)./(exp((75.5-v)/13.5)-1);