function beta_h=beta_h(v) 
beta_h=-0.017*(v+51.25)./(exp(-(v+51.25)/5.2)-1);