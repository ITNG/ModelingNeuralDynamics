function alpha_h=alpha_h(v) 
alpha_h=0.0035./exp(v/24.186);