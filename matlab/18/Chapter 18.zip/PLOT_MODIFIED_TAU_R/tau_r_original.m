function tau_r_original=tau_r_original(v);

tau_r_original=1./(exp(-14.59-0.086*v)+exp(-1.87+0.0701*v));



