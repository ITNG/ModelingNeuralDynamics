function tau_h=tau_h(v);
tau_h=1./(alpha_h(v)+beta_h(v));
