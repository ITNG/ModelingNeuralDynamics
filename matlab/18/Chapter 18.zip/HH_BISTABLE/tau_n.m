function tau_n=tau_n(v);
tau_n=1./(alpha_n(v)+beta_n(v));
