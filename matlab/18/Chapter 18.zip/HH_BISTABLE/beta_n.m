function beta_n=beta_n(v);
beta_n=0.125*exp(-(v+70)/80);

