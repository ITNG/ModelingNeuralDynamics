function beta_h=beta_h(v);
beta_h=1./(exp(-(v+40)/10)+1);