function alpha_n=alpha_n(v);
alpha_n=0.01*(-60.0d0-v)./(exp((-60-v)/10)-1);
