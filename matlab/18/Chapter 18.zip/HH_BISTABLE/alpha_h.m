function alpha_h=alpha_h(v);
alpha_h=0.07*exp(-(v+70)/20);