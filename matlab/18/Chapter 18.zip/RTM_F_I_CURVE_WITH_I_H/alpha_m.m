function alpha_m=alpha_m(v);
alpha_m=0.32*(v+54)./(1-exp(-(v+54)/4));
