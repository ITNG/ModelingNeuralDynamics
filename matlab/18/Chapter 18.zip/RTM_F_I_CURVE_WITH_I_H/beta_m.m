function beta_m=beta_m(v);
beta_m=0.28*(v+27)./(exp((v+27)/5)-1);