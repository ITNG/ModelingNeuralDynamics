function alpha_h=alpha_h(v);
alpha_h=0.128*exp(-(v+50)/18);