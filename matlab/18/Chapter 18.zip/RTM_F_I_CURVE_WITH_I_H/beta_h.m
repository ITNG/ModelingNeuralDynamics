function beta_h=beta_h(v);
beta_h=4./(1+exp(-(v+27)/5));