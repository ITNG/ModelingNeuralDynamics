function beta_n=beta_n(v);
beta_n=0.5*exp(-(v+57)/40);